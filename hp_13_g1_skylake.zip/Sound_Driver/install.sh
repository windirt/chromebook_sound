#!/bin/bash


cp -arv ./firmware/* /lib/firmware/
cp -arv ./driver/* /usr/share/alsa/ucm/
cp -arv ./system/etc/* /etc/
cp -arv ./system/lib/* /lib/


echo "Finished!!!"
echo "Type `reboot` and press ENTER now"
